package com.grafix.website;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrafixWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrafixWebsiteApplication.class, args);
	}

}
